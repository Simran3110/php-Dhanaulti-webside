<html>
<head>

<title></title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">  
  <link rel="stylesheet"  type ="text/css" href="css/style.css"> 
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@1,300&display=swap" rel="stylesheet"> 



</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Simran Bagga</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index1.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Services</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.php">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Contact</a>
        </li>

      </ul>
      <form class="d-flex">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>


<div class="jumbotron">
  <h1>Simran Bagga</h1>
  <p>dancer, web developer</p>
</div>
<section class="my-5">
<div class="py-3">
<h2 class="text-center">About Us</h2>
</div>
<div class="container-fluid">
     <div class="row">
         <div class="col-lg-6 col-md-6 col-12">
               <img src="images/ss6.jpg" class="img-fluid aboutimg">
         </div>
         <div class="col-lg-6 col-md-6 col-12">
              <h2 class="display-4">I am Simran Bagga</h2>
              <p >Simran Bagga (born Rishibala Naval;), known mononymously as Simran, is an Indian actress, producer and dancer. She has predominantly appeared in Tamil films, in addition to Telugu and Hindi films.

              Simran Bagga also known as Simran, is an Indian film actress, model and television personality. She has predominantly appeared in Tamil films, along with Telugu language films, as well as a few films in Hindi, Malayalam and Kannada. She is considered to be one of the most versatile actresses of her period.


</p>
<a href="about.php" class="btn btn-success">Check More </a>

         </div>



    </div>
</div>
</section>
<footer ><p class="p-3 bg-dark text-white text-center">@simranbaggaweb</p></footer>





</body>
</html>